Typecho Blogging Platform
=========================

Typecho is a PHP Blogging Platform. Simple and Powerful.

#### Telegram Channel
https://t.me/typechodev

#### Homepage
http://typecho.org/

#### Documents
http://docs.typecho.org/

#### Community
http://forum.typecho.org/

#### Download
http://typecho.org/download
